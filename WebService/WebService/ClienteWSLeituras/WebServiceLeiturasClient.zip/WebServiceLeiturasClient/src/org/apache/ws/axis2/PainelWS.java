package org.apache.ws.axis2;

import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.toedter.calendar.JDateChooser;

import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;

public class PainelWS extends JFrame {

	private JPanel contentPane;
	private JTextField edtQntde;
	private JTable tabelaLeituras;
	private JTextField edtDataHora;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PainelWS frame = new PainelWS();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public PainelWS() {
		setTitle("Leituras Client");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 557, 592);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblQuantidadeDeRegistros = new JLabel("Quantidade de Registros:");
		lblQuantidadeDeRegistros.setBounds(12, 14, 210, 15);
		contentPane.add(lblQuantidadeDeRegistros);

		edtQntde = new JTextField();
		edtQntde.setBounds(229, 12, 270, 19);
		contentPane.add(edtQntde);
		edtQntde.setColumns(10);

		JLabel lblNewLabel = new JLabel("Data/Hora:");
		lblNewLabel.setBounds(12, 41, 114, 15);
		contentPane.add(lblNewLabel);

		edtDataHora = new JTextField();
		edtDataHora.setBounds(229, 39, 270, 19);
		contentPane.add(edtDataHora);
		edtDataHora.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(29, 121, 502, 403);
		contentPane.add(scrollPane);
		
		final JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
	

		JButton btnEnviar = new JButton("Enviar");
		btnEnviar.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				try {
					LeiturasClient leiturasWS = new LeiturasClient();

					String lt = leiturasWS.leituras(
							Integer.parseInt(edtQntde.getText()),
							edtDataHora.getText());
				//	JOptionPane.showMessageDialog(rootPane, lt);
					Gson gson = new GsonBuilder().setPrettyPrinting().create();
					JsonParser jp = new JsonParser();
					JsonElement je = jp.parse(lt);
					String jsonOk = gson.toJson(je);
				//	System.out.println(jsonOk);
				//	textArea.setLineWrap(true);
				//	textArea.setWrapStyleWord(true);
					textArea.append(jsonOk);
					
			

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		btnEnviar.setBounds(229, 70, 117, 25);
		contentPane.add(btnEnviar);
		
		
		
	

	}
}
