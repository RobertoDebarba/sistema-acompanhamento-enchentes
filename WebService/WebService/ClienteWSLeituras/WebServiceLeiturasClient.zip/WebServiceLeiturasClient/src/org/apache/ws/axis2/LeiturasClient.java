package org.apache.ws.axis2;

import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.axis2.AxisFault;
import org.apache.ws.axis2.WebServiceLeiturasStub.Leituras;
import org.apache.ws.axis2.WebServiceLeiturasStub.LeiturasResponse;

public class LeiturasClient {

	public String leituras(int Qnde, String datahora) {
		LeiturasResponse res = null;
		try {
		
			WebServiceLeiturasStub stub = new WebServiceLeiturasStub();

			Leituras find = new Leituras();
			find.setQuantidadeRegistros(Qnde);
			find.setDataHora(datahora);
		//	find.setDataHora("2014-11-22T18:48:40.570Z");
			res = stub.leituras(find);
			
		} catch (AxisFault e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return (res.get_return());

	}

}
